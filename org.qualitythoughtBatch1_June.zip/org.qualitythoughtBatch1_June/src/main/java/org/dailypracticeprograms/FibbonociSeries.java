package org.dailypracticeprograms;

public class FibbonociSeries {

	public static void main(String[] args) {
		
			{
				int num1=0;
				int num2=1;
				System.out.println(num1);
				int fibo;
				for(int i=0;num2<=100;i++)
				{
					System.out.println(num2);
				fibo=num1+num2;
				num1=num2;
				num2=fibo;
				}
			}

			}

	}


