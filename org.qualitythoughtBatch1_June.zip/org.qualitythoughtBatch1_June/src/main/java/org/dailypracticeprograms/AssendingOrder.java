package org.dailypracticeprograms;

public class AssendingOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no[]= {2,3,5,26,1,15,16};
		//1,2,3,4,15,16,26
		int temp;
		
		for(int i=0;i<=no.length-1;i++)
		{
			for(int j=i+1;j<=no.length-1;j++)
			{
			if(no[i]>no[j])
			{
				temp=no[j];
				no[j]=no[i];
				no[i]=temp;
			}
			}
		}
		System.out.println("Ascending order is");
		for(int i=0;i<no.length-1;i++)
		{
			System.out.println(no[i]);
		}
		
		
	}

}
