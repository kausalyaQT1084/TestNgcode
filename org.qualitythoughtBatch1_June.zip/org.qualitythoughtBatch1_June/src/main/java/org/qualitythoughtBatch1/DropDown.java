package org.qualitythoughtBatch1;

public class DropDown extends MethodOverrideinSelenium{

	public void get(String string) {
		// TODO Auto-generated method stub
		System.out.println("Launched Sucessfully");
		
		
		
	}

}
