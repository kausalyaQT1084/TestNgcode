package org.qualitythoughtBatch1;
import java.util.concurrent.TimeUnit;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
 
public class ThreadSleep {
 
    public static void main(String[] args) throws InterruptedException {
        // TODO Auto-generated method stub
        
        //setting the driver executable
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
        
        //Initiating your chromedriver
        WebDriver driver=new ChromeDriver();
        
        driver.manage().window().maximize();
        
        
        driver.get("https://www.easemytrip.com/");
        
        driver.findElement(By.id("FromSector_show")).sendKeys("Delhi", Keys.ENTER);
        driver.findElement(By.id("Editbox13_show")).sendKeys("Mumbai", Keys.ENTER);
        driver.findElement(By.id("ddate")).click();
        driver.findElement(By.id("snd_4_08/08/2019")).click();
        driver.findElement(By.className("src_btn")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//button[text()='Book Now']")).click();
        
        
        
        
 
    }
 
}