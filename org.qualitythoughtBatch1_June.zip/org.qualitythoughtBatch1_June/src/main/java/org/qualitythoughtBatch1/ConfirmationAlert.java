package org.qualitythoughtBatch1;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ConfirmationAlert {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://demo.automationtesting.in/Alerts.html");
        // Maximize the browser window
        driver.manage().window().maximize();
        driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[2]/a")).click();
     // Click the "Alert with OK & Cancel" button to trigger the confirmation alert
        driver.findElement(By.xpath("//button[contains(text(),'click the button to display a confirm box')]")).click();

        // Switch to the confirmation alert
        Alert confirmationAlert = driver.switchTo().alert();

        // Get the confirmation alert text
        String confirmationText = confirmationAlert.getText();
        System.out.println("Confirmation Alert Text: " + confirmationText);

        // Accept the confirmation alert (click OK)
        Thread.sleep(4000);
        confirmationAlert.accept();

        // Alternatively, you can dismiss the confirmation alert (click Cancel)
        // confirmationAlert.dismiss();


	}

}
