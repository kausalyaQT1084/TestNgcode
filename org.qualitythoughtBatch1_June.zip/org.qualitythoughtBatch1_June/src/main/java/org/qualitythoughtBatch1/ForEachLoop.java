package org.qualitythoughtBatch1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ForEachLoop {

	public static void main(String[] args) {
		String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		System.out.println(driverPath);
		// Launch the browser
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		
		driver.get("https://www.tutorialspoint.com/about/about_careers.htm");
		// identify elements in menu with findElements
	      List<WebElement> p = driver.
	      findElements(By.xpath("//ul[@class='toc reading']/li"));
	      System.out.println("Menu Items are: ");
	      //iterate through list
	      for( WebElement i: p){
	         System.out.println(i.getText());
	}
	}
}
