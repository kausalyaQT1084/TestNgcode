package org.qualitythoughtBatch1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class FrameandIframe {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		System.out.println(driverPath);
		// Launch the browser
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
driver.get("https://demoqa.com/nestedframes");
		
		
		//Count number of frames available on webpage
        int total_frame= driver.findElements(By.id("frame")).size();
		//int total_frame= driver.findElements(By.id("frame")).size();
		System.out.print("Toatl Frames avilable on WebPage : "+total_frame);
		
	  //Accesing child frame
		
		driver.switchTo().frame("frame2").switchTo().frame(0); 
		
		WebElement text1 = driver.findElement(By.id("frame2Wrapper"));
		System.out.print("\n Available text on Frame: "+text1.getText());
		
		//Accessing parent frame.....
		
		driver.switchTo().parentFrame();
		//WebElement text = driver.findElement(By.xpath("//div[@id='google_ads_iframe_/21849154601,22343295815/Ad.Plus-Anchor_0__container__']/iframe));
		//System.out.print("\n Available text on Frame: "+text.getText());
		
		driver.switchTo().frame("iframeResult");// Switch By ID
	
		//Switching back to the main window
		driver.switchTo().defaultContent();
		
		driver.findElement(By.className("main-header"));
		
		Thread.sleep(5000);
		

		
		//driver.quit();
	}

}
