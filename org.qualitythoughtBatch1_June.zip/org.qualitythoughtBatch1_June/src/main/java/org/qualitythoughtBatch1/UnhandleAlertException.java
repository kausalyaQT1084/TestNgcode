package org.qualitythoughtBatch1;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class UnhandleAlertException {
	
 public static void main(String[] args) {
	        // Set the path to the chromedriver executable
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
	
	        try {
	            // Navigate to the URL
	            driver.get("https://demo.automationtesting.in/Alerts.html");

	            // Click the button to trigger the alert
	            driver.manage().window().maximize();
		        driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[3]/a")).click();
		        driver.findElement(By.xpath("//div[@id='Textbox']/button")).click();

	            // Simulate a failure by not handling the alert
	            // Let the UnhandledAlertException be thrown

	        } catch (UnhandledAlertException ex) {
	            // Handle the UnhandledAlertException here
	            System.out.println("UnhandledAlertException occurred. Alert was not handled.");

	            // Get the alert and print its text
	            Alert alert = driver.switchTo().alert();
	            System.out.println("Alert text: " + alert.getText());

	            // Accept the alert (click OK)
	            alert.accept();
	        } finally {
	            // Close the browser
	          System.out.println("Alert Handled Properly");
	        }
	    }
	}


