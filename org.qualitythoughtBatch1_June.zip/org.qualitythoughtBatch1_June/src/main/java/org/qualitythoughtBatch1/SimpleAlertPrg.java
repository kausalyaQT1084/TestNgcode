package org.qualitythoughtBatch1;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SimpleAlertPrg {
    public static void main(String[] args) throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
        // Maximize the browser window
        driver.manage().window().maximize();

        driver.get("https://demo.automationtesting.in/Alerts.html");

        // Click the "Alert with OK" button to trigger the alert
        driver.findElement(By.xpath("//div[@id='OKTab']/button")).click();

        // Switch to the alert
        Alert alert = driver.switchTo().alert();

        // Get the alert text
        Thread.sleep(3000);
        String alertText = alert.getText();
        System.out.println("Alert Text: " + alertText);

        // Accept the alert (click OK)
        //alert.accept();
        alert.dismiss();


     
    }
}
