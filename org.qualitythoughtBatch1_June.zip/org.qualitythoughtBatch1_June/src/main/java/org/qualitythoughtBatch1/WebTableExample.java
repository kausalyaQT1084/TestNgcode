package org.qualitythoughtBatch1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class WebTableExample {
    public static void main(String[] args) throws InterruptedException {
        // Set the path to the chromedriver executable
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
        // Maximize the browser window
        driver.manage().window().maximize();

     // Navigate to the web page with the table
     // Launch the web application
        driver.get("https://demo.seleniumeasy.com/table-sort-search-demo.html");

        // Sort the table by "Date" column
        WebElement nameHeader = driver.findElement(By.xpath("//thead[@class='thead-inverse']/tr/th[@class='sorting'][4]"));
        nameHeader.click();
        
        
       //to take the Values in WebTable
        
        WebElement tablevalue =driver.findElement(By.xpath("//tbody/tr[@role='row'][5]/td[4]"));
        tablevalue.getText();

        // Wait for the table to be sorted
        WebDriverWait webdwait = new WebDriverWait(driver, Duration.ofSeconds(10));
    	Boolean e=webdwait.until(ExpectedConditions.attributeContains(nameHeader, "Ashton Cox", "ascending"));

       
        // Search for a specific value in the table
        WebElement searchInput = driver.findElement(By.xpath("//input[@id='example_filter']/label/input"));
        searchInput.sendKeys("Cairo");

        // Wait for the table to be filtered
        webdwait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//table[@id='example']//td[1]"), "Cairo"));



    }}