package org.qualitythoughtBatch1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class MultipleSelection {

	public static void main(String[] args) {
	     // Set the path to the chromedriver executable
	    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			options.merge(capabilities);
			ChromeDriver driver = new ChromeDriver(options);
	        // Maximize the browser window
	        driver.manage().window().maximize();
	        driver.get("http://demo.seleniumeasy.com/basic-select-dropdown-demo.html");
	     //  // Locate the multi-select dropdown element
	        WebElement multiSelectDropdown = driver.findElement(By.id("multi-select"));

	        // Create a Select object for the dropdown
	        Select select = new Select(multiSelectDropdown);

	        // Check if the dropdown supports multiple selections
	        if (select.isMultiple()) {
	            // Select options by value
	            select.selectByValue("California");
	            select.selectByValue("Florida");
	            select.selectByValue("New York");
	            
	        }	        }}
	


