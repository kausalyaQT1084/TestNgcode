package org.qualitythoughtBatch1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DatePickerExample {

	public static void main(String[] args) throws InterruptedException {
		
		String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		System.out.println(driverPath);
		// Launch the browser
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);

	/// Launch the web application
		driver.get("http://demo.seleniumeasy.com/bootstrap-date-picker-demo.html");

        // Locate the date input field and click on it to open the date picker
        WebElement dateInput = driver.findElement(By.xpath("//div[@id='sandbox-container1']//input"));
        dateInput.click();

        // Wait for the date picker to be visible
        WebDriverWait webdwait = new WebDriverWait(driver, Duration.ofSeconds(10));
    	WebElement datePicker=webdwait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='datepicker-days']")));

       // WebDriverWait wait = new WebDriverWait(driver, 10);
      //  WebElement datePicker = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='datepicker-days']")));

        // Select the desired date
    	Thread.sleep(3000);
        WebElement desiredDate = datePicker.findElement(By.xpath("//tr/td[@class='day' and text()='4']"));
        desiredDate.click();
	}

}
