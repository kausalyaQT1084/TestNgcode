package org.qualitythoughtBatch1;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class WindowsHandlingprg1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		//Load the url
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://www.amazon.in/");
		driver.manage().window().maximize();
		WebElement s=driver.findElement(By.xpath("//*[@id=\"glow-ingress-line1\"]"));
		String k=driver.getWindowHandle();
		System.out.println(s);
		WebElement iphone= driver.findElement(By.id("twotabsearchtextbox"));
		iphone.sendKeys("iphone");
	
		WebElement search = driver.findElement(By.id("nav-search-submit-button"));
		search.click();
		String pwid=driver.getWindowHandle();
		System.out.println(pwid);
		Thread.sleep(7000);
		
		//I have to explain link without Action class 
		
	//Error 1: org.openqa.selenium.ElementClickInterceptedException : 
	//Error 2: org.openqa.selenium.StaleElementReferenceException:
		//Actions act =  new Actions(driver);
		//act.moveToElement(driver.findElement(By.xpath("//span[@class='a-truncate-full a-offscreen'][1]")));
		//act.click().perform();
		//WebElement s =driver.findElement(By.className("SearchInput__input__IGt2m"));
		//String wind2=driver.getWindowHandle();
		//System.out.println(wind2);
		
		// To move with next window
		Actions act =  new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath("//label/input[@type='checkbox']")));
		act.click().perform();
		//driver.findElement(By.xpath("//label/input[@type='checkbox']")).click();
		String s2=driver.getWindowHandle();
		System.out.println(s2);
		
	    
	}

}
