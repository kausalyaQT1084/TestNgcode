package org.qualitythoughtBatch1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class DropDownS {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://demo.automationtesting.in/Register.html");
		// Locate the dropdown element
        WebElement dropdownElement = driver.findElement(By.id("Skills"));

        // Create a Select object for the dropdown
        Select dropdown = new Select(dropdownElement);

        // Select an option by visible text
        //dropdown.selectByVisibleText("Java");
        dropdown.selectByIndex(10);
	}

}
