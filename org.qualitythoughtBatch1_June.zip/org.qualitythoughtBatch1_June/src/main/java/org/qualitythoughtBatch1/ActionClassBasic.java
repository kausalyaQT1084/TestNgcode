package org.qualitythoughtBatch1;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class ActionClassBasic {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		//Load the url
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://www.google.com/");
        driver.manage().window().maximize();
        WebElement element = driver.findElement(By.name("q"));
        Actions action = new Actions(driver);
        action.moveToElement(element)
        .keyDown(Keys.SHIFT)
        .sendKeys("Selenium Webdriver")
        .keyUp(Keys.SHIFT)
        .doubleClick()
        .contextClick()
        .clickAndHold()
        .scrollToElement(element)
        .build()
        .perform();
        Thread.sleep(5000);
        
    	driver.get("http://www.facebook.com/");
    	WebElement txtUsername = driver.findElement(By.id("email"));
    	WebElement txtPassword = driver.findElement(By.id("passContainer"));
    	
    	Actions builder = new Actions(driver);
    	Action seriesOfActions = builder
    		.moveToElement(txtUsername)
    		.click()
    		.keyDown(txtUsername, Keys.SHIFT)
    		.sendKeys(txtUsername, "kausalya24@gmail.com")
    		.keyUp(txtUsername, Keys.SHIFT)
    		.doubleClick(txtUsername)
    		.contextClick()
    		.moveToElement(txtPassword)
    		.click()
    		.keyDown(txtPassword, Keys.SHIFT)
    		.sendKeys(txtPassword, "Ilove@2010")
    		.doubleClick(txtPassword)
    		.build();
    	seriesOfActions.perform() ;
        }
	}


