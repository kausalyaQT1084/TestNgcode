package inheritance;

public class One {
		
		public void details(){
			System.out.println("Learning Java");
		}
		
	}

