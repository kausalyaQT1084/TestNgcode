package inheritance;

public class RecordofStudent  extends AutomationTestingStudent{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AutomationTestingStudent mt = new AutomationTestingStudent();
		mt.studentDetail();
		mt.details();
		

	}

}
