package inheritance;

public class AutomationTestingStudent extends ManualTestingStudent {
	public void details() {
	String name ="Raghavan";
	int ids =11;
	System.out.println(name);

	}
}
