package testNgFramework;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.Test;

public class ListenersExample extends BaseClass implements ITestListener {
	public static WebDriver driver;
	 @Test  
	public void executionStarting(ITestContext context) {
	        System.out.println("Test Suite started: " + context.getSuite().getName());
	        String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
	          ChromeOptions options = new ChromeOptions();	    
	    	options.addArguments("--remote-allow-origins=*");
	    	DesiredCapabilities capabilities = new DesiredCapabilities();
	    	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	    	options.merge(capabilities);
	    	driver = new ChromeDriver(options);
		driver.get("https://magento.softwaretestingboard.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/ul/li[2]/a")).click();
	    }
	    
	  @Test
	  public void womenExecution(ITestContext context) {
			 Actions actions = new Actions(driver);
			 
		      actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-4\"]/span[2]"))).perform();
		      actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-9\"]/span[2]"))).perform();
		       driver.findElement(By.xpath("//*[@id=\"ui-id-11\"]/span")).click();
		     String gettilte= driver.findElement(By.xpath("//div[@class='page-title-wrapper']/h1")).getText();
		     System.out.println(gettilte);
		}
	    
	  
	    public void onTestStart(ITestResult result) {
	        System.out.println("Test Case started: " + result.getName());
	        // Add your custom code here
	    }
	    
	 
	    public void onTestSuccess(ITestResult result) {
	        System.out.println("Test Case passed: " + result.getName());
	        // Add your custom code here
	    }
	    
	
	    public void onTestFailure(ITestResult result) {
	        System.out.println("Test Case failed: " + result.getName());
	        // Add your custom code here
	    }
	    
	   


}
