package readandWriteExcel;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;

public class WritetheExcelwithoutMAP {
	public static void main(String[] args) 
	 {
		        // Create a new workbook
		        Workbook workbook = new XSSFWorkbook();

		        // Create a new sheet
		        Sheet sheet = workbook.createSheet("Worker");

		        // Create rows and cells with data
		        Row headerRow = sheet.createRow(0);
		       
		        headerRow.createCell(0).setCellValue("Name");
		        headerRow.createCell(1).setCellValue("Age");
		        headerRow.createCell(2).setCellValue("Email");
		        headerRow.createCell(3).setCellValue("PHoneNumber");

		        Row dataRow = sheet.createRow(1);
		        dataRow.createCell(0).setCellValue("John Doe");
		        dataRow.createCell(1).setCellValue(30);
		        dataRow.createCell(2).setCellValue("johndoe@example.com");

		        // Save the workbook to an Excel file
		       try (FileOutputStream fileOutputStream = new FileOutputStream("C:\\Users\\kausa\\OneDrive\\Desktop\\QT Classes\\Selenium Batches\\QT1.xlsx")) {
		            workbook.write(fileOutputStream);
		           
		            System.out.println("Excel file created successfully!");
		        } catch (IOException e) {
		            e.printStackTrace();
		        } finally {
		            // Close the workbook
		            try {
		                workbook.close();
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
		        }
		    }
		


	}


